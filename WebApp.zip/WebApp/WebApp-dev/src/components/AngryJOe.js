import React from 'react'

const AngryJOe = () => {
  return (
    <div className="angryjoe">
      <h1>Not selected any servers</h1>
        <img src="cross.png" className="angryjoe-img" alt='error'></img>

    </div>
  )
}
export default AngryJOe