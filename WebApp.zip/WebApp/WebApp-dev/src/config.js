export const Config = {
	appRoot      :	'/',

	server       :   {
		"getData"						: "//localhost/dashboard/test/getData.php"
	}

}
